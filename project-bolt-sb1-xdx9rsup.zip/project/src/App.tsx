import React, { useState } from 'react';
import { Sprout, CheckSquare, FileText, Building2 } from 'lucide-react';
import { AppProvider } from './context/AppContext';
import { TaskForm } from './components/TaskForm';
import { TaskTable } from './components/TaskTable';
import { TaskEditModal } from './components/TaskEditModal';
import { ProjectForm } from './components/ProjectForm';
import { ProjectTable } from './components/ProjectTable';
import { ProjectEditModal } from './components/ProjectEditModal';
import { Stats } from './components/Stats';

const BANKS = [
  'Banco do Brasil',
  'Sicoob Centro', 
  'Cresol',
  'Bradesco',
  'Basa',
  'Sicredi',
  'Sicoob Amazônia',
  'Caixa'
];

type TabType = 'dashboard' | 'tasks' | 'projects' | string;

function AppContent() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');

  const TabButton = ({ id, icon: Icon, label, isActive }: {
    id: TabType;
    icon: any;
    label: string;
    isActive: boolean;
  }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
        isActive
          ? 'bg-green-600 text-white shadow-md'
          : 'text-gray-600 hover:text-green-600 hover:bg-green-50'
      }`}
    >
      <Icon className="h-4 w-4" />
      {label}
    </button>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div>
            <Stats />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-4">Tarefas Recentes</h2>
                <TaskTable />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-4">Projetos Recentes</h2>
                <ProjectTable />
              </div>
            </div>
          </div>
        );
      
      case 'tasks':
        return (
          <div>
            <TaskForm />
            <TaskTable />
          </div>
        );
      
      case 'projects':
        return (
          <div>
            <ProjectForm />
            <ProjectTable />
          </div>
        );
      
      default:
        // Bank-specific view
        const bankName = activeTab;
        return (
          <div>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                <Building2 className="h-6 w-6 text-blue-600" />
                {bankName}
              </h2>
              <p className="text-gray-600 mt-1">Projetos específicos desta instituição</p>
            </div>
            <ProjectTable bankFilter={bankName} />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="bg-green-600 p-2 rounded-lg">
                <Sprout className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">AgroManager</h1>
                <p className="text-sm text-gray-500">Sistema de Gestão Rural</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-1 py-4 overflow-x-auto">
            <TabButton
              id="dashboard"
              icon={CheckSquare}
              label="Dashboard"
              isActive={activeTab === 'dashboard'}
            />
            <TabButton
              id="tasks"
              icon={CheckSquare}
              label="Tarefas Diárias"
              isActive={activeTab === 'tasks'}
            />
            <TabButton
              id="projects"
              icon={FileText}
              label="Projetos Rurais"
              isActive={activeTab === 'projects'}
            />
            
            {/* Bank tabs */}
            <div className="w-px bg-gray-300 mx-2 self-stretch" />
            {BANKS.map(bank => (
              <TabButton
                key={bank}
                id={bank}
                icon={Building2}
                label={bank}
                isActive={activeTab === bank}
              />
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>

      {/* Modals */}
      <TaskEditModal />
      <ProjectEditModal />

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center text-sm text-gray-500">
            <p>© 2025 AgroManager - Sistema de Gestão Rural</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;