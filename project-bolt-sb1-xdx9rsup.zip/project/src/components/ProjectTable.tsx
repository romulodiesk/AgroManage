import React from 'react';
import { Building2, DollarSign, Calendar, Trash2, FileText, Edit, Shield, Package } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Project } from '../types';

interface ProjectTableProps {
  bankFilter?: string;
}

export function ProjectTable({ bankFilter }: ProjectTableProps) {
  const { state, dispatch } = useApp();

  const filteredProjects = state.projects.filter(project => {
    const bankMatch = bankFilter ? project.instituicao === bankFilter : 
      (!state.filters.projectBank || project.instituicao === state.filters.projectBank);
    const statusMatch = !state.filters.projectStatus || project.status === state.filters.projectStatus;
    return bankMatch && statusMatch;
  });

  const getStatusBadge = (status: Project['status']) => {
    const baseClasses = "px-2 py-1 rounded-full text-xs font-medium";
    switch (status) {
      case 'Aprovado':
        return `${baseClasses} bg-green-100 text-green-800`;
      case 'Em análise':
        return `${baseClasses} bg-blue-100 text-blue-800`;
      case 'Pendente':
        return `${baseClasses} bg-yellow-100 text-yellow-800`;
      default:
        return `${baseClasses} bg-gray-100 text-gray-800`;
    }
  };

  const getTypeBadge = (tipo: Project['tipo']) => {
    return tipo === 'Custeio' 
      ? "px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800"
      : "px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800";
  };

  const handleEdit = (project: Project) => {
    dispatch({ type: 'SET_EDITING_PROJECT', payload: project });
  };

  const handleDelete = (projectId: string) => {
    if (window.confirm('Tem certeza que deseja excluir este projeto?')) {
      dispatch({ type: 'DELETE_PROJECT', payload: projectId });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          {bankFilter ? `Projetos - ${bankFilter}` : 'Projetos Rurais'}
        </h3>
        
        {!bankFilter && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Filtrar por Instituição
              </label>
              <select
                value={state.filters.projectBank}
                onChange={(e) => dispatch({ 
                  type: 'SET_FILTER', 
                  payload: { key: 'projectBank', value: e.target.value } 
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Todas as instituições</option>
                <option value="Banco do Brasil">Banco do Brasil</option>
                <option value="Sicoob Centro">Sicoob Centro</option>
                <option value="Cresol">Cresol</option>
                <option value="Bradesco">Bradesco</option>
                <option value="Basa">Basa</option>
                <option value="Sicredi">Sicredi</option>
                <option value="Sicoob Amazônia">Sicoob Amazônia</option>
                <option value="Caixa">Caixa</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Filtrar por Status
              </label>
              <select
                value={state.filters.projectStatus}
                onChange={(e) => dispatch({ 
                  type: 'SET_FILTER', 
                  payload: { key: 'projectStatus', value: e.target.value } 
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Todos os status</option>
                <option value="À Enviar">À Enviar</option>
                <option value="Em análise">Em análise</option>
                <option value="Pendente">Pendente</option>
                <option value="Aprovado">Aprovado</option>
              </select>
            </div>
          </div>
        )}
      </div>

      <div className="overflow-x-auto">
        {filteredProjects.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            <FileText className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <p>Nenhum projeto encontrado</p>
          </div>
        ) : (
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Projeto
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Proponente
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Instituição
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Valor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Garantias
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Item Financiável
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Observações
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredProjects.map((project) => (
                <tr key={project.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {project.item || 'Projeto Rural'}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={getTypeBadge(project.tipo)}>
                          {project.tipo}
                        </span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{project.proponente}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Building2 className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-900">{project.instituicao}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <DollarSign className="h-4 w-4 text-gray-400 mr-1" />
                      <span className="text-sm font-medium text-gray-900">
                        {project.valor.toLocaleString('pt-BR', { 
                          style: 'currency', 
                          currency: 'BRL' 
                        })}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={getStatusBadge(project.status)}>
                      {project.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-start">
                      <Shield className="h-4 w-4 text-gray-400 mr-2 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-900 max-w-xs truncate" title={project.garantias}>
                        {project.garantias || 'Não informado'}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-start">
                      <Package className="h-4 w-4 text-gray-400 mr-2 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-900 max-w-xs truncate" title={project.item}>
                        {project.item || 'Não especificado'}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-900">
                        {new Date(project.data).toLocaleDateString('pt-BR')}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900 max-w-xs truncate" title={project.observacoes}>
                      {project.observacoes || 'Sem observações'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleEdit(project)}
                        className="text-blue-600 hover:text-blue-800 transition-colors"
                        title="Editar projeto"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(project.id)}
                        className="text-red-600 hover:text-red-800 transition-colors"
                        title="Excluir projeto"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}