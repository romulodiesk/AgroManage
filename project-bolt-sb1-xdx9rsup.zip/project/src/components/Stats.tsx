import React from 'react';
import { CheckCircle, Clock, AlertCircle, DollarSign, FileText, Building2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function Stats() {
  const { state } = useApp();

  const taskStats = {
    total: state.tasks.length,
    completed: state.tasks.filter(t => t.status === 'Concluído').length,
    inProgress: state.tasks.filter(t => t.status === 'Em andamento').length,
    pending: state.tasks.filter(t => t.status === 'Pendente').length,
  };

  const projectStats = {
    total: state.projects.length,
    approved: state.projects.filter(p => p.status === 'Aprovado').length,
    inAnalysis: state.projects.filter(p => p.status === 'Em análise').length,
    totalValue: state.projects.reduce((sum, p) => sum + p.valor, 0),
  };

  const bankStats = state.projects.reduce((acc, project) => {
    acc[project.instituicao] = (acc[project.instituicao] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const StatCard = ({ title, value, icon: Icon, color, subtitle }: {
    title: string;
    value: string | number;
    icon: any;
    color: string;
    subtitle?: string;
  }) => (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center">
        <div className={`flex-shrink-0 p-3 rounded-lg ${color}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
        <div className="ml-4">
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <p className="text-2xl font-semibold text-gray-900">{value}</p>
          {subtitle && <p className="text-xs text-gray-400">{subtitle}</p>}
        </div>
      </div>
    </div>
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <StatCard
        title="Total de Tarefas"
        value={taskStats.total}
        icon={FileText}
        color="bg-blue-500"
        subtitle={`${taskStats.completed} concluídas`}
      />
      
      <StatCard
        title="Tarefas Pendentes"
        value={taskStats.pending}
        icon={AlertCircle}
        color="bg-red-500"
      />
      
      <StatCard
        title="Total de Projetos"
        value={projectStats.total}
        icon={Building2}
        color="bg-green-500"
        subtitle={`${projectStats.approved} aprovados`}
      />
      
      <StatCard
        title="Valor Total"
        value={projectStats.totalValue.toLocaleString('pt-BR', { 
          style: 'currency', 
          currency: 'BRL',
          maximumFractionDigits: 0 
        })}
        icon={DollarSign}
        color="bg-purple-500"
        subtitle="Em projetos"
      />
    </div>
  );
}