import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { AppState, Task, Project } from '../types';

type AppAction =
  | { type: 'ADD_TASK'; payload: Omit<Task, 'id' | 'createdAt'> }
  | { type: 'ADD_PROJECT'; payload: Omit<Project, 'id' | 'createdAt'> }
  | { type: 'UPDATE_TASK'; payload: Task }
  | { type: 'UPDATE_PROJECT'; payload: Project }
  | { type: 'DELETE_TASK'; payload: string }
  | { type: 'DELETE_PROJECT'; payload: string }
  | { type: 'SET_FILTER'; payload: { key: keyof AppState['filters']; value: string } }
  | { type: 'SET_EDITING_TASK'; payload: Task | null }
  | { type: 'SET_EDITING_PROJECT'; payload: Project | null }
  | { type: 'LOAD_DATA'; payload: AppState };

const initialState: AppState = {
  tasks: [],
  projects: [],
  filters: {
    taskStatus: '',
    taskDate: '',
    projectBank: '',
    projectStatus: '',
  },
  editingTask: null,
  editingProject: null,
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'ADD_TASK':
      const newTask: Task = {
        ...action.payload,
        id: crypto.randomUUID(),
        createdAt: new Date().toISOString(),
      };
      return { ...state, tasks: [...state.tasks, newTask] };

    case 'ADD_PROJECT':
      const newProject: Project = {
        ...action.payload,
        id: crypto.randomUUID(),
        createdAt: new Date().toISOString(),
      };
      return { ...state, projects: [...state.projects, newProject] };

    case 'UPDATE_TASK':
      return {
        ...state,
        tasks: state.tasks.map(task =>
          task.id === action.payload.id ? action.payload : task
        ),
        editingTask: null,
      };

    case 'UPDATE_PROJECT':
      return {
        ...state,
        projects: state.projects.map(project =>
          project.id === action.payload.id ? action.payload : project
        ),
        editingProject: null,
      };

    case 'DELETE_TASK':
      return {
        ...state,
        tasks: state.tasks.filter(task => task.id !== action.payload),
      };

    case 'DELETE_PROJECT':
      return {
        ...state,
        projects: state.projects.filter(project => project.id !== action.payload),
      };

    case 'SET_FILTER':
      return {
        ...state,
        filters: { ...state.filters, [action.payload.key]: action.payload.value },
      };

    case 'SET_EDITING_TASK':
      return {
        ...state,
        editingTask: action.payload,
      };

    case 'SET_EDITING_PROJECT':
      return {
        ...state,
        editingProject: action.payload,
      };

    case 'LOAD_DATA':
      return { ...action.payload, editingTask: null, editingProject: null };

    default:
      return state;
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedData = localStorage.getItem('rural-management-data');
    if (savedData) {
      try {
        const parsedData = JSON.parse(savedData);
        dispatch({ type: 'LOAD_DATA', payload: parsedData });
      } catch (error) {
        console.error('Error loading saved data:', error);
      }
    }
  }, []);

  // Save data to localStorage whenever state changes
  useEffect(() => {
    const dataToSave = {
      tasks: state.tasks,
      projects: state.projects,
      filters: state.filters,
    };
    localStorage.setItem('rural-management-data', JSON.stringify(dataToSave));
  }, [state.tasks, state.projects, state.filters]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}