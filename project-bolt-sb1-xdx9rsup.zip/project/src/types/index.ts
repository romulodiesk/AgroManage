export interface Task {
  id: string;
  tarefa: string;
  responsavel: string;
  status: 'Pendente' | 'Em andamento' | 'Concluído';
  data: string;
  createdAt: string;
}

export interface Project {
  id: string;
  tipo: 'Custeio' | 'Investimento';
  instituicao: 'Banco do Brasil' | 'Sicoob Centro' | 'Cresol' | 'Bradesco' | 'Basa' | 'Sicredi' | 'Sicoob Amazônia' | 'Caixa';
  proponente: string;
  garantias: string;
  valor: number;
  item: string;
  data: string;
  status: 'À Enviar' | 'Em análise' | 'Pendente' | 'Aprovado';
  observacoes: string;
  createdAt: string;
}

export interface AppState {
  tasks: Task[];
  projects: Project[];
  filters: {
    taskStatus: string;
    taskDate: string;
    projectBank: string;
    projectStatus: string;
  };
  editingTask: Task | null;
  editingProject: Project | null;
}